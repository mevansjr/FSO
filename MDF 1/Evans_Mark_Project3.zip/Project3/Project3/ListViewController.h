//
//  FirstViewController.h
//  Project3
//
//  Created by Mark Evans on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "MyAnnotation.h"

@interface ListViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
{
    IBOutlet UITableView *mapTableView;
    NSMutableArray *showArray;
    MyAnnotation* passAnn;
}
@property (nonatomic, retain) NSMutableArray *showArray;

@end
