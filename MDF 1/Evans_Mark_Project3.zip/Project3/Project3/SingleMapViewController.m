//
//  SingleMapViewController.m
//  Project3
//
//  Created by Mark Evans on 6/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SingleMapViewController.h"
#import <MapKit/MapKit.h>
#import "ListViewController.h"
#import "MyAnnotation.h"
#import "AppDelegate.h"

@interface SingleMapViewController ()

@end

@implementation SingleMapViewController
@synthesize theMapView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (IBAction)showMap:(CLLocationCoordinate2D)coord title:(NSString *)title
{
    NSString *mCoord = [[NSString alloc]initWithFormat:@"Lon: %f Lat: %f", coord.longitude, coord.latitude];
    
    name.text = title;
    lonlat.text = mCoord;
    
    MKCoordinateRegion newRegion;
    newRegion.center.latitude = coord.latitude;
    newRegion.center.longitude = coord.longitude;
    newRegion.span.latitudeDelta = 0.0333;
    newRegion.span.longitudeDelta = 0.0333;
    
    self.theMapView.delegate = (id)self;
    
    [self.theMapView setRegion:newRegion animated:YES];
    
    CLLocationCoordinate2D location;
    location.latitude = coord.latitude;
    location.longitude = coord.longitude;
	
	passAnnotation=[[MyAnnotation alloc] init];
    
	passAnnotation.coordinate=location;
	passAnnotation.title=title;
	passAnnotation.subtitle=@"Food";
    
    [theMapView addAnnotation:passAnnotation];
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
    if ([annotation isKindOfClass:[MKUserLocation class]])
        return nil;
    
    MKPinAnnotationView* pinView = (MKPinAnnotationView*)[self.theMapView dequeueReusableAnnotationViewWithIdentifier:@"MyAnnotation"];
    
    if (!pinView) 
        pinView = [[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"CustomPinAnnotation"];
    else
        //pinView.annotation = annotation;
        //pinView.animatesDrop = YES;
        //pinView.canShowCallout = YES;
        pinView.enabled = YES;
        pinView.canShowCallout = YES;
        pinView.image=[UIImage imageNamed:@"pin.png"];
        //pinView.pinColor = MKPinAnnotationColorPurple;
    
    return pinView;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
