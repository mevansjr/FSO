//
//  ListMapViewController.m
//  Project3
//
//  Created by Mark Evans on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ListMapViewController.h"
#import <MapKit/MapKit.h>
#import "ListViewController.h"
#import "MyAnnotation.h"
#import "AppDelegate.h"

@interface ListMapViewController ()

@end

@implementation ListMapViewController
@synthesize listViewMap;
@synthesize nshowArray;
@synthesize mshowArray;
@synthesize loc, loc2, loc3, loc4, loc5, loc6, loc7, loc8, loc9, loc10;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Map", @"Map");
        self.tabBarItem.image = [UIImage imageNamed:@"marker"];
    }
    return self;
}

- (void)showMap:(CLLocationCoordinate2D)coord title:(NSString *)title
{
    MKCoordinateRegion newRegion;
    newRegion.center.latitude = coord.latitude;
    newRegion.center.longitude = coord.longitude;
    newRegion.span.latitudeDelta = 0.0333;
    newRegion.span.longitudeDelta = 0.0333;
    
    [self.listViewMap setRegion:newRegion animated:YES];
    
    CLLocationCoordinate2D location;
    location.latitude = coord.latitude;
    location.longitude = coord.longitude;
	
	passAnnotation=[[MyAnnotation alloc] init];
    
	passAnnotation.coordinate=location;
	passAnnotation.title=title;
	passAnnotation.subtitle=@"Food";
    
    [listViewMap addAnnotation:passAnnotation];
}

- (void)fromRemove:(NSMutableArray *)pArray
{
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate Array];
    nshowArray = appDelegate.Array;
    
    NSLog(@"listmap from app del : %i",appDelegate.Array.count);
    NSLog(@"listmap copied array from app del : %i",nshowArray.count);
    
//    loc = [appDelegate.Array objectAtIndex:0];
//    loc2 = [appDelegate.Array objectAtIndex:1];
//    loc3 = [appDelegate.Array objectAtIndex:2];
//    loc4 = [appDelegate.Array objectAtIndex:3];
//    loc5 = [appDelegate.Array objectAtIndex:4];
//    loc6 = [appDelegate.Array objectAtIndex:5];
//    loc7 = [appDelegate.Array objectAtIndex:6];
//    loc8 = [appDelegate.Array objectAtIndex:7];
//    loc9 = [appDelegate.Array objectAtIndex:8];
//    loc10 = [appDelegate.Array objectAtIndex:9];
    
    MKCoordinateRegion newRegion;
    newRegion.center.latitude = loc.coordinate.latitude;
    newRegion.center.longitude = loc.coordinate.longitude;
    newRegion.span.latitudeDelta = 1.3333;
    newRegion.span.longitudeDelta = 1.3333;
    
    [self.listViewMap setRegion:newRegion animated:YES];
    
    //	passAnnotation=[[MyAnnotation alloc]init];
    //    
    //	passAnnotation.coordinate=location;
    //	passAnnotation.title=title;
    //	passAnnotation.subtitle=@"Food";
    if (loc != NULL){
        [listViewMap addAnnotation:loc];
    }
    if (loc2 != NULL){
        [listViewMap addAnnotation:loc2];
    }
    if (loc3 != NULL){
        [listViewMap addAnnotation:loc3];
    }
    if (loc4 != NULL){
        [listViewMap addAnnotation:loc4];
    }
    if (loc5 != NULL){
        [listViewMap addAnnotation:loc5];
    }
    if (loc6 != NULL){
        [listViewMap addAnnotation:loc6];
    }
    if (loc7 != NULL){
        [listViewMap addAnnotation:loc7];
    }
    if (loc8 != NULL){
        [listViewMap addAnnotation:loc8];
    }
    if (loc9 != NULL){
        [listViewMap addAnnotation:loc9];
    }
    if (loc10 != NULL){
        [listViewMap addAnnotation:loc10];
    }
}


- (void)viewDidLoad
{
    [super viewDidLoad]; 
    self.navigationController.navigationBar.tintColor=[UIColor blackColor];
//    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
//    [appDelegate Array];
//    nshowArray = appDelegate.Array;
//    
//    NSLog(@"listmap from app del : %i",appDelegate.Array.count);
//    NSLog(@"listmap copied array from app del : %i",nshowArray.count);
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:TRUE];
    
    MKCoordinateRegion newRegion;
    newRegion.center.latitude = 39.350;
    newRegion.center.longitude = -76.350;
    newRegion.span.latitudeDelta = 1.3333;
    newRegion.span.longitudeDelta = 1.3333;
    
    [self.listViewMap setRegion:newRegion animated:YES];
    
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate Array];
    nshowArray = appDelegate.Array;
    
    NSLog(@"listmap from app del : %i",appDelegate.Array.count);
    NSLog(@"listmap copied array from app del : %i",nshowArray.count);
    
    NSMutableArray *locs = [[NSMutableArray alloc] initWithArray:nshowArray];
    [listViewMap removeAnnotations:locs];
    for (int i = 0; nshowArray.count > i; i++) 
    {
        MyAnnotation *theloc = [nshowArray objectAtIndex:i];
        [listViewMap addAnnotation:theloc];
    }
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{	
    if ([annotation isKindOfClass:[MKUserLocation class]])
        return nil;

	static NSString* AnnotationIdentifier = @"AnnotationIdentifier";
	MKPinAnnotationView* pinView = [[MKPinAnnotationView alloc]initWithAnnotation:annotation reuseIdentifier:AnnotationIdentifier];
	pinView.animatesDrop=YES;
	pinView.canShowCallout=YES;
	pinView.pinColor=MKPinAnnotationColorPurple;
	
	return pinView;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    [nshowArray setArray:nil];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
