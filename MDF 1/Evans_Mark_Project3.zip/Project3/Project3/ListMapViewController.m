//
//  ListMapViewController.m
//  Project3
//
//  Created by Mark Evans on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ListMapViewController.h"
#import <MapKit/MapKit.h>
#import "ListViewController.h"
#import "MapViewController.h"

@interface ListMapViewController ()

@end

@implementation AddressAnnotation

@synthesize coordinate;

- (NSString *)subtitle
{
	return subTitle;
}

- (void)setSubTitle:(NSString *)subtitleIn
{
	subTitle = subtitleIn;
}

- (NSString *)title
{
	return title;
}

- (void)setTitle:(NSString *)titleIn
{
	title = titleIn;
}

-(id)initWithCoordinate:(CLLocationCoordinate2D) c
{
	coordinate=c;
	NSLog(@"%f,%f",c.latitude,c.longitude);
	return self;
}

@end

@implementation ListMapViewController


- (void)makeAnnotationAtLocation:(CLLocationCoordinate2D)coord title:(NSString *)locTitle
{
    MKCoordinateRegion region;
	MKCoordinateSpan span;
	span.latitudeDelta=0.002;
	span.longitudeDelta=0.002;
	
	CLLocationCoordinate2D location = coord;
	
	location.latitude = coord.latitude;
	location.longitude = coord.longitude;
	region.span=span;
	region.center=location;
	
	if(addAnnotation1 != nil) {
		[listViewMap removeAnnotation:addAnnotation1];
		addAnnotation1 = nil;
	}
	
	addAnnotation1 = [[AddressAnnotation alloc] initWithCoordinate:location];
    [addAnnotation1 setTitle:self.title];
	[addAnnotation1 setSubTitle:@"Food"];
	[listViewMap addAnnotation:addAnnotation1];
	
	[listViewMap setRegion:region animated:TRUE];
	[listViewMap regionThatFits:region];
    
    //center map on coord if you want to...
}

- (MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation
{
	MKPinAnnotationView *annView=[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"currentloc"];
	annView.pinColor = MKPinAnnotationColorGreen;
	annView.animatesDrop=TRUE;
	annView.canShowCallout = YES;
	annView.calloutOffset = CGPointMake(-5, 5);
	return annView;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (IBAction)passName:(NSString *)myName
{
    self.title = myName;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
