//
//  ListMapViewController.h
//  Project3
//
//  Created by Mark Evans on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

#define METERS_PER_MILE 1609.344

@interface AddressAnnotation : NSObject <MKAnnotation> 
{
	CLLocationCoordinate2D coordinate;
	NSString *title;
	NSString *subTitle;
}

@end

@interface ListMapViewController : UIViewController <MKMapViewDelegate>
{
    IBOutlet MKMapView *listViewMap;
    AddressAnnotation *addAnnotation1;
}
- (IBAction)passName:(NSString *)myName;
- (void)makeAnnotationAtLocation:(CLLocationCoordinate2D)coord title:(NSString *)locTitle;

@end
