//
//  FirstViewController.m
//  Project3
//
//  Created by Mark Evans on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ListViewController.h"
#import <MapKit/MapKit.h>
#import "ListMapViewController.h"
#import "Locations.h"
#import "MapViewController.h"

@interface ListViewController ()

@end

@implementation ListViewController

@synthesize myLocs;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"List", @"List");
        self.tabBarItem.image = [UIImage imageNamed:@"first"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    myLocs = [NSMutableArray arrayWithCapacity:myLocs.count];
    
    Locations *aLoc1 = [[Locations alloc]init];
    aLoc1.name = @"McDonalds";
    aLoc1.myLon = [NSString stringWithFormat:@"%@", @"-76.624146"];
    aLoc1.myLat = [NSString stringWithFormat:@"%@", @"39.288874"];
    [myLocs addObject:aLoc1];
    
    Locations *aLoc2 = [[Locations alloc]init];
    aLoc2.name = @"Burger King";
    aLoc2.myLon = [NSString stringWithFormat:@"%@", @"-77.182238"];
    aLoc2.myLat = [NSString stringWithFormat:@"%@", @"39.119765"];
    [myLocs addObject:aLoc2];
    
    Locations *aLoc3 = [[Locations alloc]init];
    aLoc3.name = @"Jack in the Box";
    aLoc3.myLon = [NSString stringWithFormat:@"%@", @"-33.2779787"];
    aLoc3.myLat = [NSString stringWithFormat:@"%@", @"-44.4349773"];
    [myLocs addObject:aLoc3];
    
    Locations *aLoc4 = [[Locations alloc]init];
    aLoc4.name = @"KFC";
    aLoc4.myLon = [NSString stringWithFormat:@"%@", @"-33.2779787"];
    aLoc4.myLat = [NSString stringWithFormat:@"%@", @"-44.4349773"];
    [myLocs addObject:aLoc4];
    
    Locations *aLoc5 = [[Locations alloc]init];
    aLoc5.name = @"Taco Bell";
    aLoc5.myLon = [NSString stringWithFormat:@"%@", @"-33.2779787"];
    aLoc5.myLat = [NSString stringWithFormat:@"%@", @"-44.4349773"];
    [myLocs addObject:aLoc5];
    
    Locations *aLoc6 = [[Locations alloc]init];
    aLoc6.name = @"Roy Rodgers";
    aLoc6.myLon = [NSString stringWithFormat:@"%@", @"-33.2779787"];
    aLoc6.myLat = [NSString stringWithFormat:@"%@", @"-44.4349773"];
    [myLocs addObject:aLoc6];
    
    Locations *aLoc7 = [[Locations alloc]init];
    aLoc7.name = @"Carls Jr";
    aLoc7.myLon = [NSString stringWithFormat:@"%@", @"-33.2779787"];
    aLoc7.myLat = [NSString stringWithFormat:@"%@", @"-44.4349773"];
    [myLocs addObject:aLoc7];
    
    Locations *aLoc8 = [[Locations alloc]init];
    aLoc8.name = @"Pizza Hut";
    aLoc8.myLon = [NSString stringWithFormat:@"%@", @"-77.107372"];
    aLoc8.myLat = [NSString stringWithFormat:@"%@", @"39.045153"];
    [myLocs addObject:aLoc8];
    
    Locations *aLoc9 = [[Locations alloc]init];
    aLoc9.name = @"Long John Silvers";
    aLoc9.myLon = [NSString stringWithFormat:@"%@", @"-33.2779787"];
    aLoc9.myLat = [NSString stringWithFormat:@"%@", @"-44.4349773"];
    [myLocs addObject:aLoc9];
    
    Locations *aLoc10 = [[Locations alloc]init];
    aLoc10.name = @"Sonic";
    aLoc10.myLon = [NSString stringWithFormat:@"%@", @"-33.2779787"];
    aLoc10.myLat = [NSString stringWithFormat:@"%@", @"-44.4349773"];
    [myLocs addObject:aLoc10];

    MapViewController *mapViewController = [[MapViewController alloc] init];
    [mapViewController passLat:aLoc1.myLat passLon:aLoc1.myLon passName:aLoc1.name passArr:myLocs];
    
    self.navigationController.navigationBar.tintColor=[UIColor blackColor];
    UIBarButtonItem *rightButton =[[UIBarButtonItem alloc]initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(toggleEdit)];
    self.navigationItem.rightBarButtonItem = rightButton;
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

-(void)toggleEdit{
    [mapTableView setEditing:!mapTableView.editing animated:YES]; 
    
    if (mapTableView.editing) 
    {
        [self.navigationItem.rightBarButtonItem setTitle:@"Done"];
    }
    else 
    {
        [self.navigationItem.rightBarButtonItem setTitle:@"Edit"];  
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return myLocs.count;  
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(editingStyle == UITableViewCellEditingStyleDelete)
    {
        [myLocs removeObjectAtIndex:indexPath.row];
        [mapTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:true];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    Locations *loc = [self.myLocs objectAtIndex:indexPath.row];
	cell.textLabel.text = loc.name;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //Code to click through to detailed view controller
    ListMapViewController *myMap = [[ListMapViewController alloc] initWithNibName:@"ListMapViewController" bundle:nil];
    if (myMap != nil)
    {
        [self.navigationController pushViewController:myMap animated:YES];
        //pushes players name from table to label on DetailsViewController
        Locations *showName = [self.myLocs objectAtIndex:indexPath.row];
        Locations *showLon = [self.myLocs objectAtIndex:indexPath.row];
        Locations *showLat = [self.myLocs objectAtIndex:indexPath.row];
        [myMap passName:showName.name];
        
//        [myMap passLat:showLat.myLat];
//        [myMap passLon:showLon.myLon];
//        [myMap passCords:showCords];
                
        CLLocationCoordinate2D location;
        NSString *titleLocation = showName.name;
        location.latitude   = showLat.myLat.doubleValue;
        location.longitude  = showLon.myLon.doubleValue;
        
        [myMap makeAnnotationAtLocation:location title:titleLocation];
        
        NSLog(@"Lat/Log: %f/%f", location.latitude, location.longitude);
        
    }
}

@end
