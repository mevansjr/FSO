//
//  FirstViewController.m
//  Project3
//
//  Created by Mark Evans on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ListViewController.h"
#import <MapKit/MapKit.h>
#import "ListMapViewController.h"
#import "MyAnnotation.h"
#import "AppDelegate.h"

@interface ListViewController ()

@end

@implementation ListViewController
@synthesize showArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Locations", @"Locations");
        self.tabBarItem.image = [UIImage imageNamed:@"map"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    self.navigationController.navigationBar.tintColor=[UIColor blackColor];
    UIBarButtonItem *rightButton =[[UIBarButtonItem alloc]initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(toggleEdit)];
    self.navigationItem.rightBarButtonItem = rightButton;
    //UIBarButtonItem *leftButton =[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(toggleAdd)]; 
    self.navigationItem.rightBarButtonItem = rightButton;
    //self.navigationItem.leftBarButtonItem = leftButton;
    [super viewDidLoad];
    
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate showArr];
    showArray = appDelegate.Array;
    
    CLLocationCoordinate2D theCoordinate1;
    theCoordinate1.latitude = 39.323;
    theCoordinate1.longitude = -76.413;
	
	CLLocationCoordinate2D theCoordinate2;
    theCoordinate2.latitude = 39.443;
    theCoordinate2.longitude = -76.243;
	
	CLLocationCoordinate2D theCoordinate3;
    theCoordinate3.latitude = 39.143;
    theCoordinate3.longitude = -76.513;
	
	CLLocationCoordinate2D theCoordinate4;
    theCoordinate4.latitude = 39.173;
    theCoordinate4.longitude = -76.783;
    
    CLLocationCoordinate2D theCoordinate5;
    theCoordinate5.latitude = 39.323;
    theCoordinate5.longitude = -76.713;
    
    CLLocationCoordinate2D theCoordinate6;
    theCoordinate6.latitude = 39.343;
    theCoordinate6.longitude = -76.563;
    
    CLLocationCoordinate2D theCoordinate7;
    theCoordinate7.latitude = 39.189;
    theCoordinate7.longitude = -76.513;
    
    CLLocationCoordinate2D theCoordinate8;
    theCoordinate8.latitude = 39.443;
    theCoordinate8.longitude = -76.214;
    
    CLLocationCoordinate2D theCoordinate9;
    theCoordinate9.latitude = 39.343;
    theCoordinate9.longitude = -76.313;
    
    CLLocationCoordinate2D theCoordinate10;
    theCoordinate10.latitude = 39.543;
    theCoordinate10.longitude = -76.313;
	
	MyAnnotation* myAnnotation1=[[MyAnnotation alloc] init];
    
	myAnnotation1.coordinate=theCoordinate1;
	myAnnotation1.title=@"McDonalds";
	myAnnotation1.subtitle=@"Food";
	
	MyAnnotation* myAnnotation2=[[MyAnnotation alloc] init];
	
	myAnnotation2.coordinate=theCoordinate2;
	myAnnotation2.title=@"Burger King";
	myAnnotation2.subtitle=@"Food";
	
	MyAnnotation* myAnnotation3=[[MyAnnotation alloc] init];
	
	myAnnotation3.coordinate=theCoordinate3;
	myAnnotation3.title=@"Jack in the Box";
	myAnnotation3.subtitle=@"Food";
	
	MyAnnotation* myAnnotation4=[[MyAnnotation alloc] init];
	
	myAnnotation4.coordinate=theCoordinate4;
	myAnnotation4.title=@"KFC";
	myAnnotation4.subtitle=@"Food";
    
    MyAnnotation* myAnnotation5=[[MyAnnotation alloc] init];
    
	myAnnotation5.coordinate=theCoordinate5;
	myAnnotation5.title=@"Taco Bell";
	myAnnotation5.subtitle=@"Food";
	
	MyAnnotation* myAnnotation6=[[MyAnnotation alloc] init];
	
	myAnnotation6.coordinate=theCoordinate6;
	myAnnotation6.title=@"Roy Rodgers";
	myAnnotation6.subtitle=@"Food";
	
	MyAnnotation* myAnnotation7=[[MyAnnotation alloc] init];
	
	myAnnotation7.coordinate=theCoordinate7;
	myAnnotation7.title=@"Carls Jr";
	myAnnotation7.subtitle=@"Food";
	
	MyAnnotation* myAnnotation8=[[MyAnnotation alloc] init];
	
	myAnnotation8.coordinate=theCoordinate8;
	myAnnotation8.title=@"Pizza Hut";
	myAnnotation8.subtitle=@"Food";
    
    MyAnnotation* myAnnotation9=[[MyAnnotation alloc] init];
	
	myAnnotation9.coordinate=theCoordinate9;
	myAnnotation9.title=@"Long John Silvers";
	myAnnotation9.subtitle=@"Food";
	
	MyAnnotation* myAnnotation10=[[MyAnnotation alloc] init];
	
	myAnnotation10.coordinate=theCoordinate10;
	myAnnotation10.title=@"Sonic";
	myAnnotation10.subtitle=@"Food";
    
	[showArray addObject:myAnnotation1];
	[showArray addObject:myAnnotation2];
	[showArray addObject:myAnnotation3];
	[showArray addObject:myAnnotation4];
    [showArray addObject:myAnnotation5];
    [showArray addObject:myAnnotation6];
    [showArray addObject:myAnnotation7];
    [showArray addObject:myAnnotation8];
    [showArray addObject:myAnnotation9];
    [showArray addObject:myAnnotation10];
    
    NSLog(@"from app del : %i",appDelegate.Array.count);
    NSLog(@"copied array from app del : %i",showArray.count);
    
	// Do any additional setup after loading the view, typically from a nib.
}

-(void)toggleEdit
{
    [mapTableView setEditing:!mapTableView.editing animated:YES]; 
    
    if (mapTableView.editing) 
    {
        [self.navigationItem.rightBarButtonItem setTitle:@"Done"];
    }
    else 
    {
        [self.navigationItem.rightBarButtonItem setTitle:@"Edit"];  
    }
}

//-(void)toggleAdd
//{
//    //Add code here
//    NSLog(@"Add button was selected!");
//}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return showArray.count;  
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(editingStyle == UITableViewCellEditingStyleDelete)
    {
        [showArray removeObjectAtIndex:indexPath.row];
        NSLog(@"copied array from app del : %i",showArray.count);
        [mapTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:true];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    MyAnnotation *loc = [showArray objectAtIndex:indexPath.row];
	cell.textLabel.text = loc.title;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ListMapViewController *myMap = [[ListMapViewController alloc] initWithNibName:@"ListMapViewController" bundle:nil];
    if (myMap != nil)
    {
        [self.navigationController pushViewController:myMap animated:YES];
        MyAnnotation *showCoord = [showArray objectAtIndex:indexPath.row];
        [myMap showMap:showCoord.coordinate title:showCoord.title];
    }
}

@end
