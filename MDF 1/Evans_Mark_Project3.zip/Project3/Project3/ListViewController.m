//
//  FirstViewController.m
//  Project3
//
//  Created by Mark Evans on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ListViewController.h"
#import <MapKit/MapKit.h>
#import "ListMapViewController.h"
#import "MyAnnotation.h"
#import "AppDelegate.h"

@interface ListViewController ()

@end

@implementation ListViewController
@synthesize showArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Locations", @"Locations");
        self.tabBarItem.image = [UIImage imageNamed:@"map"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    self.navigationController.navigationBar.tintColor=[UIColor blackColor];
    UIBarButtonItem *rightButton =[[UIBarButtonItem alloc]initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(toggleEdit)];
    self.navigationItem.rightBarButtonItem = rightButton;
    [super viewDidLoad];
    
    AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    [appDelegate showArr];
    showArray = appDelegate.Array;
    
    NSLog(@"from app del : %i",appDelegate.Array.count);
    NSLog(@"copied array from app del : %i",showArray.count);
    
	// Do any additional setup after loading the view, typically from a nib.
}

-(void)toggleEdit{
    [mapTableView setEditing:!mapTableView.editing animated:YES]; 
    
    if (mapTableView.editing) 
    {
        [self.navigationItem.rightBarButtonItem setTitle:@"Done"];
    }
    else 
    {
        [self.navigationItem.rightBarButtonItem setTitle:@"Edit"];  
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return showArray.count;  
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(editingStyle == UITableViewCellEditingStyleDelete)
    {
        [showArray removeObjectAtIndex:indexPath.row];
        NSLog(@"copied array from app del : %i",showArray.count);
        [mapTableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:true];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    MyAnnotation *loc = [showArray objectAtIndex:indexPath.row];
	cell.textLabel.text = loc.title;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ListMapViewController *myMap = [[ListMapViewController alloc] initWithNibName:@"ListMapViewController" bundle:nil];
    if (myMap != nil)
    {
        [self.navigationController pushViewController:myMap animated:YES];
        MyAnnotation *showCoord = [showArray objectAtIndex:indexPath.row];
        [myMap showMap:showCoord.coordinate title:showCoord.title];
    }
}

@end
