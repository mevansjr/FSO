//
//  Locations.m
//  Project3
//
//  Created by Mark Evans on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Locations.h"

@implementation Locations
@synthesize name;
@synthesize myLon;
@synthesize myLat;



@end
