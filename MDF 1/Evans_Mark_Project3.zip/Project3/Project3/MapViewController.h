//
//  SecondViewController.h
//  Project3
//
//  Created by Mark Evans on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

#define METERS_PER_MILE 1609.344

@interface AddressAnnotations : NSObject <MKAnnotation> 
{
	CLLocationCoordinate2D coordinate;
	NSString *title;
	NSString *subTitle;
}

@end

@interface MapViewController : UIViewController <MKMapViewDelegate>
{
    IBOutlet MKMapView *mapView;
    AddressAnnotations *addAnnotation1;
    AddressAnnotations *addAnnotation2;
}
- (IBAction)showMap;
- (IBAction)passLat:(NSString*)aLat passLon:(NSString*)aLon passName:(NSString *)name passArr:(NSMutableArray *)arr;

@property NSString *savedName;
@property NSString *savedLat;
@property NSString *savedLon;

@end
