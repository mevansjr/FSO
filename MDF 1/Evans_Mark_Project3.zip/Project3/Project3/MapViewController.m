//
//  SecondViewController.m
//  Project3
//
//  Created by Mark Evans on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "MapViewController.h"
#import <MapKit/MapKit.h>
#import "ListViewController.h"
#import "AddressAnnotation.h"
#import "Locations.h"

@interface MapViewController ()

@end

@implementation AddressAnnotations

@synthesize coordinate;

- (NSString *)subtitle
{
	return subTitle;
}

- (void)setSubTitle:(NSString *)subtitleIn
{
	subTitle = subtitleIn;
}

- (NSString *)title
{
	return title;
}

- (void)setTitle:(NSString *)titleIn
{
	title = titleIn;
}

-(id)initWithCoordinate:(CLLocationCoordinate2D) c
{
	coordinate=c;
	NSLog(@"%f,%f",c.latitude,c.longitude);
	return self;
}

@end

@implementation MapViewController

@synthesize savedName;
@synthesize savedLat;
@synthesize savedLon;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Map", @"Map");
        self.tabBarItem.image = [UIImage imageNamed:@"second"];
    }
    return self;
}

- (IBAction)passLat:(NSString *)aLat passLon:(NSString *)aLon passName:(NSString *)name passArr:(NSMutableArray *)arr
{
    MKCoordinateRegion region;
	MKCoordinateSpan span;
	span.latitudeDelta=2.25;
	span.longitudeDelta=2.25;
    
    Locations *loc1 = [arr objectAtIndex:0];
    
    CLLocationCoordinate2D location = mapView.userLocation.coordinate;
    location.latitude   = loc1.myLat.doubleValue;
    location.longitude  = loc1.myLon.doubleValue;
	region.span=span;
	region.center=location;
	
	if(addAnnotation1 != nil) {
		[mapView removeAnnotation:addAnnotation1];
		addAnnotation1 = nil;
	}
	
	addAnnotation1 = [[AddressAnnotations alloc] initWithCoordinate:location];
	[addAnnotation1 setTitle:loc1.name];
	[addAnnotation1 setSubTitle:@"Food"];
	[mapView addAnnotation:addAnnotation1];
	
    Locations *second = [[Locations alloc] init];
    second.name = @"Burger King";
    second.myLon = [NSString stringWithFormat:@"%@", @"-77.182238"];
    second.myLat = [NSString stringWithFormat:@"%@", @"39.119765"];
    
	CLLocationCoordinate2D location2 = mapView.userLocation.coordinate;
	location2.latitude = second.myLat.doubleValue;
	location2.longitude = second.myLon.doubleValue;
	
	if(addAnnotation2 != nil) 
	{
		[mapView removeAnnotation:addAnnotation2];
		addAnnotation2 = nil;
	}
	
	addAnnotation2 = [[AddressAnnotations alloc] initWithCoordinate:location2];
	[addAnnotation2 setTitle:@"RFK Stadium"];
	[addAnnotation2 setSubTitle:@"Once home, of the once proud Redskins"];
	[mapView addAnnotation:addAnnotation2];
	
	
	[mapView setRegion:region animated:TRUE];
	[mapView regionThatFits:region];
}

- (IBAction)showMap 
{
//    MKCoordinateRegion region;
//	MKCoordinateSpan span;
//	span.latitudeDelta=2.25;
//	span.longitudeDelta=2.25;
//    
//    CLLocationCoordinate2D location = mapView.userLocation.coordinate;
//    location.latitude   = savedLat.doubleValue;
//    location.longitude  = savedLon.doubleValue;
//	region.span=span;
//	region.center=location;
//	
//	if(addAnnotation1 != nil) {
//		[mapView removeAnnotation:addAnnotation1];
//		addAnnotation1 = nil;
//	}
//	
//	addAnnotation1 = [[AddressAnnotations alloc] initWithCoordinate:location];
//	[addAnnotation1 setTitle:savedName];
//	[addAnnotation1 setSubTitle:@"Food"];
//	[mapView addAnnotation:addAnnotation1];
//	
//    Locations *second = [[Locations alloc] init];
//    second.name = @"Burger King";
//    second.myLon = [NSString stringWithFormat:@"%@", @"-77.182238"];
//    second.myLat = [NSString stringWithFormat:@"%@", @"39.119765"];
//    
//	CLLocationCoordinate2D location2 = mapView.userLocation.coordinate;
//	location2.latitude = second.myLat.doubleValue;
//	location2.longitude = second.myLon.doubleValue;
//	
//	if(addAnnotation2 != nil) 
//	{
//		[mapView removeAnnotation:addAnnotation2];
//		addAnnotation2 = nil;
//	}
//	
//	addAnnotation2 = [[AddressAnnotations alloc] initWithCoordinate:location2];
//	[addAnnotation2 setTitle:@"RFK Stadium"];
//	[addAnnotation2 setSubTitle:@"Once home, of the once proud Redskins"];
//	[mapView addAnnotation:addAnnotation2];
//	
//	
//	[mapView setRegion:region animated:TRUE];
//	[mapView regionThatFits:region];
}

- (MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation
{
	MKPinAnnotationView *annView=[[MKPinAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:@"currentloc"];
	annView.pinColor = MKPinAnnotationColorGreen;
	annView.animatesDrop=TRUE;
	annView.canShowCallout = YES;
	annView.calloutOffset = CGPointMake(-5, 5);
	return annView;
}
							
- (void)viewDidLoad
{
    MKCoordinateRegion region;
	MKCoordinateSpan span;
	span.latitudeDelta=20.25;
	span.longitudeDelta=20.25;
    
    [mapView addAnnotation:addAnnotation1];
    if(addAnnotation1 != nil) {
		[mapView removeAnnotation:addAnnotation1];
		addAnnotation1 = nil;
	}
    
    [mapView setRegion:region animated:TRUE];
	[mapView regionThatFits:region];
    
    [super viewDidLoad];
    //[self showMap];
    
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
