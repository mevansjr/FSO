//
//  AppDelegate.m
//  Project3
//
//  Created by Mark Evans on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AppDelegate.h"

#import "ListViewController.h"

#import "ListMapViewController.h"

@implementation AppDelegate

@synthesize window = _window;
@synthesize tabBarController = _tabBarController;
@synthesize Array;
@synthesize loc, loc2, loc3, loc4, loc5, loc6, loc7, loc8, loc9, loc10;


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]];
    // Override point for customization after application launch.
    UIViewController *viewController1 = [[ListViewController alloc] initWithNibName:@"ListViewController" bundle:nil];
    UINavigationController *navController = [[UINavigationController alloc] initWithRootViewController:viewController1];
    UIViewController *viewController2 = [[ListMapViewController alloc] initWithNibName:@"ListMapViewController" bundle:nil];
    UINavigationController *navController2 = [[UINavigationController alloc] initWithRootViewController:viewController2];
    self.tabBarController = [[UITabBarController alloc] init];
    self.tabBarController.viewControllers = [NSArray arrayWithObjects:navController, navController2, nil];
    self.window.rootViewController = self.tabBarController;
    [self.window makeKeyAndVisible];
    return YES;
}

-(void)showArr
{
	CLLocationCoordinate2D theCoordinate1;
    theCoordinate1.latitude = 39.323;
    theCoordinate1.longitude = -76.413;
	
	CLLocationCoordinate2D theCoordinate2;
    theCoordinate2.latitude = 39.443;
    theCoordinate2.longitude = -76.243;
	
	CLLocationCoordinate2D theCoordinate3;
    theCoordinate3.latitude = 39.143;
    theCoordinate3.longitude = -76.513;
	
	CLLocationCoordinate2D theCoordinate4;
    theCoordinate4.latitude = 39.173;
    theCoordinate4.longitude = -76.783;
    
    CLLocationCoordinate2D theCoordinate5;
    theCoordinate5.latitude = 39.323;
    theCoordinate5.longitude = -76.713;
    
    CLLocationCoordinate2D theCoordinate6;
    theCoordinate6.latitude = 39.343;
    theCoordinate6.longitude = -76.563;
    
    CLLocationCoordinate2D theCoordinate7;
    theCoordinate7.latitude = 39.189;
    theCoordinate7.longitude = -76.513;
    
    CLLocationCoordinate2D theCoordinate8;
    theCoordinate8.latitude = 39.443;
    theCoordinate8.longitude = -76.214;
    
    CLLocationCoordinate2D theCoordinate9;
    theCoordinate9.latitude = 39.343;
    theCoordinate9.longitude = -76.313;
    
    CLLocationCoordinate2D theCoordinate10;
    theCoordinate10.latitude = 39.543;
    theCoordinate10.longitude = -76.313;
	
	MyAnnotation* myAnnotation1=[[MyAnnotation alloc] init];
    
	myAnnotation1.coordinate=theCoordinate1;
	myAnnotation1.title=@"McDonalds";
	myAnnotation1.subtitle=@"Food";
	
	MyAnnotation* myAnnotation2=[[MyAnnotation alloc] init];
	
	myAnnotation2.coordinate=theCoordinate2;
	myAnnotation2.title=@"Burger King";
	myAnnotation2.subtitle=@"Food";
	
	MyAnnotation* myAnnotation3=[[MyAnnotation alloc] init];
	
	myAnnotation3.coordinate=theCoordinate3;
	myAnnotation3.title=@"Jack in the Box";
	myAnnotation3.subtitle=@"Food";
	
	MyAnnotation* myAnnotation4=[[MyAnnotation alloc] init];
	
	myAnnotation4.coordinate=theCoordinate4;
	myAnnotation4.title=@"KFC";
	myAnnotation4.subtitle=@"Food";
    
    MyAnnotation* myAnnotation5=[[MyAnnotation alloc] init];
    
	myAnnotation5.coordinate=theCoordinate5;
	myAnnotation5.title=@"Taco Bell";
	myAnnotation5.subtitle=@"Food";
	
	MyAnnotation* myAnnotation6=[[MyAnnotation alloc] init];
	
	myAnnotation6.coordinate=theCoordinate6;
	myAnnotation6.title=@"Roy Rodgers";
	myAnnotation6.subtitle=@"Food";
	
	MyAnnotation* myAnnotation7=[[MyAnnotation alloc] init];
	
	myAnnotation7.coordinate=theCoordinate7;
	myAnnotation7.title=@"Carls Jr";
	myAnnotation7.subtitle=@"Food";
	
	MyAnnotation* myAnnotation8=[[MyAnnotation alloc] init];
	
	myAnnotation8.coordinate=theCoordinate8;
	myAnnotation8.title=@"Pizza Hut";
	myAnnotation8.subtitle=@"Food";
    
    MyAnnotation* myAnnotation9=[[MyAnnotation alloc] init];
	
	myAnnotation9.coordinate=theCoordinate9;
	myAnnotation9.title=@"Long John Silvers";
	myAnnotation9.subtitle=@"Food";
	
	MyAnnotation* myAnnotation10=[[MyAnnotation alloc] init];
	
	myAnnotation10.coordinate=theCoordinate10;
	myAnnotation10.title=@"Sonic";
	myAnnotation10.subtitle=@"Food";
    
	Array = [[NSMutableArray alloc] initWithCapacity:Array.count];
    
	[Array addObject:myAnnotation1];
	[Array addObject:myAnnotation2];
	[Array addObject:myAnnotation3];
	[Array addObject:myAnnotation4];
    [Array addObject:myAnnotation5];
    [Array addObject:myAnnotation6];
    [Array addObject:myAnnotation7];
    [Array addObject:myAnnotation8];
    [Array addObject:myAnnotation9];
    [Array addObject:myAnnotation10];
    
    NSLog(@"%i",Array.count);

}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

/*
// Optional UITabBarControllerDelegate method.
- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
}
*/

/*
// Optional UITabBarControllerDelegate method.
- (void)tabBarController:(UITabBarController *)tabBarController didEndCustomizingViewControllers:(NSArray *)viewControllers changed:(BOOL)changed
{
}
*/

@end
