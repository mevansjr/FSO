//
//  SingleMapViewController.h
//  Project3
//
//  Created by Mark Evans on 6/13/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "MyAnnotation.h"

@interface SingleMapViewController : UIViewController
{
    IBOutlet MKMapView *theMapView;
    MyAnnotation* passAnnotation;
    MyAnnotation* passAnnotation2;
    IBOutlet UILabel *name;
    IBOutlet UILabel *lonlat;
}
@property IBOutlet MKMapView *theMapView;
- (IBAction)showMap:(CLLocationCoordinate2D)coord title:(NSString *)title;

@end
