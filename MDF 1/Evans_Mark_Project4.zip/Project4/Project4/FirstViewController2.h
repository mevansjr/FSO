//
//  FirstViewController2.h
//  Project4
//
//  Created by Mark Evans on 6/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController2 : UIViewController
{
    IBOutlet UITextView *myTextView;
    NSMutableString *outputText;
}
-(void)passName:(NSString*)theName age:(NSString*)theAge email:(NSString*)theEmail;

@end
