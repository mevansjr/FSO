//
//  FirstViewController.m
//  Project4
//
//  Created by Mark Evans on 6/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FirstViewController.h"
#import "FirstViewController2.h"
#import "Persons.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"XML List", @"XML List");
        self.tabBarItem.image = [UIImage imageNamed:@"list"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    self.navigationController.navigationBar.tintColor=[UIColor blackColor];
    items = 0;
    persons = [[NSMutableArray alloc] init];
    url = [[NSURL alloc] initWithString:@"http://www.markevansjr.com/persons.xml"];
    request = [[NSURLRequest alloc] initWithURL:url];
    if (request != nil)
    {
        connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    }
    requestData = [NSMutableData data];
    NSData *xmlData = [self GetFileDataFromFile:@"xmlFile.xml"];
    NSXMLParser *parser = [[NSXMLParser alloc] initWithData:xmlData];
    if (parser != nil)
    {
        [parser setDelegate:self];
        [parser parse];
    }
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName attributes:(NSDictionary *)attributeDict
{
    if ([elementName isEqualToString:@"PersonList"])
    {
        NSString *itemsStr = [attributeDict valueForKey:@"items"];
        if (itemsStr != nil)
        {
            items = [itemsStr intValue];
        }
    }
    else if ([elementName isEqualToString:@"Person"])
    {
        NSString *name = [attributeDict valueForKey:@"name"];
        NSString *age = [attributeDict valueForKey:@"age"];
        NSString *email = [attributeDict valueForKey:@"email"];
        Persons *item = [[Persons alloc] initWithName:name theAge:age theEmail:email];
        if (item != nil)
        {
            [persons addObject:item];
        }
    }
}

- (NSData*)GetFileDataFromFile:(NSString*)filename
{
    NSString *filePath = nil;
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    filePath = [documentsDirectory stringByAppendingPathComponent:filename];
    if ([fileManager fileExistsAtPath:filePath])
    {
        return  [NSData dataWithContentsOfFile:filePath];
    }
    return nil;
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    if (data != nil)
    {
        [requestData appendData:data];
    }
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *requestString = [[NSString alloc] initWithData:requestData encoding:NSASCIIStringEncoding];
    if (requestString != nil)
    {
        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
        NSString *documentsDirectory = [paths objectAtIndex:0];
        if (documentsDirectory !=nil)
        {
            NSString *fullPath = [[NSString alloc] initWithFormat:@"%@/%@",documentsDirectory, @"xmlFile.xml"];
            if (fullPath != nil)
            {
                [requestData writeToFile:fullPath atomically:true];
            }
        }
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return persons.count;  
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    Persons *personName = [persons objectAtIndex:indexPath.row];
    NSString *theName = [personName valueForKey:@"name"];
    NSLog(@"%@",theName);
	cell.textLabel.text = theName;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    FirstViewController2 *firstView2 = [[FirstViewController2 alloc] initWithNibName:@"FirstViewController2" bundle:nil];
    [self.navigationController pushViewController:firstView2 animated:TRUE];
    Persons *personName = [persons objectAtIndex:indexPath.row];
    NSString *theName = [personName valueForKey:@"name"];
    NSString *theAge = [personName valueForKey:@"age"];
    NSString *theEmail = [personName valueForKey:@"email"];
    NSLog(@"passed %@",theName);
    NSLog(@"passed %@",theAge);
    NSLog(@"passed %@",theEmail);
    [firstView2 passName:theName age:theAge email:theEmail];
    
}

@end
