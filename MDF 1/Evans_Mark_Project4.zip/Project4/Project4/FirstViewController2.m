//
//  FirstViewController2.m
//  Project4
//
//  Created by Mark Evans on 6/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FirstViewController2.h"

@interface FirstViewController2 ()

@end

@implementation FirstViewController2

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

-(void)passName:(NSString*)theName age:(NSString*)theAge email:(NSString*)theEmail
{
    self.title = theName;
    NSString *tempName = [[NSString alloc] initWithFormat:@"%@",theName];
    NSString *tempAge = [[NSString alloc] initWithFormat:@"\n %@",theAge];
    NSString *tempEmail = [[NSString alloc] initWithFormat:@"\n %@",theEmail];
    myTextView.text = @"";
    outputText = [NSMutableString stringWithString:myTextView.text];
    [outputText appendString:tempName];
    [outputText appendString:tempAge];
    [outputText appendString:tempEmail];
    myTextView.text = outputText;
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

@end
