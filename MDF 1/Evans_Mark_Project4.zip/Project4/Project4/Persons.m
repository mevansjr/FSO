//
//  Persons.m
//  Project4
//
//  Created by Mark Evans on 6/18/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Persons.h"

@implementation Persons

-(id)initWithName:(NSString*)personName theAge:(NSString*)personAge theEmail:(NSString*)personEmail
{
    if ((self = [super init]))
    {
        name = personName;
        age = personAge;
        email = personEmail;
    }
    return self;
}

@end
