//
//  FirstViewController.h
//  Project4
//
//  Created by Mark Evans on 6/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, NSURLConnectionDelegate, NSURLConnectionDataDelegate, NSXMLParserDelegate>
{
    IBOutlet UITableView *myTableView;
    NSURL *url;
    NSURLRequest *request;
    NSURLConnection *connection;
    NSMutableData *requestData;
    NSMutableArray *persons;
    NSInteger items;
}

@end
