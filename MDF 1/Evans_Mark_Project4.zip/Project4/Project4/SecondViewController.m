//
//  SecondViewController.m
//  Project4
//
//  Created by Mark Evans on 6/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SecondViewController.h"

@interface SecondViewController ()

@end

@implementation SecondViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Browser", @"Browser");
        self.tabBarItem.image = [UIImage imageNamed:@"browser"];
    }
    return self;
}
							
- (void)viewDidLoad
{
    url = [[NSURL alloc] initWithString:@"http://www.markevansjr.com/persons.xml"];
    request = [[NSURLRequest alloc] initWithURL:url];
    if (request != nil)
    {
        connection = [[NSURLConnection alloc] initWithRequest:request delegate:self];
    }
    if (!myWebView.canGoBack)
    {
        backButton.enabled = false;
    }
    myWebView.scalesPageToFit = YES;
    [myWebView loadRequest:request];
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

-(IBAction)onClick:(id)sender
{
    UIBarButtonItem *item = (UIBarButtonItem*)sender;
    if (item.tag == 0)
    {
        if (myWebView.canGoBack)
        {
            [myWebView goBack];
            
            backButton.enabled = (myWebView.canGoBack);
        }
    }
    else if (item.tag == 1)
    {
        if (myWebView.isLoading)
        {
            [myWebView stopLoading];
        }
    }
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    backButton.enabled = (myWebView.canGoBack);
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
