//
//  Persons.h
//  Project4
//
//  Created by Mark Evans on 6/18/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Persons : NSObject
{
    NSString *name;
    NSString *age;
    NSString *email;
}
-(id)initWithName:(NSString*)personName theAge:(NSString*)personAge theEmail:(NSString*)personEmail;

@end
