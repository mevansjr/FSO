//
//  FirstViewController.m
//  Project2
//
//  Created by Mark Evans on 6/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "FirstViewController.h"
#import "SecondViewController.h"
#import "AltFirstViewController.h"

@interface FirstViewController ()

@end

@implementation FirstViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Baltimore", @"Baltimore");
        self.tabBarItem.image = [UIImage imageNamed:@"Home"];
        
    }
    return self;
}

-(IBAction) onClick:(id)sender
{
	NSLog(@"Showing detail");
	AltFirstViewController *altFirstViewController = [[AltFirstViewController alloc] initWithNibName:@"AltFirstViewController" bundle:nil];
	[self.navigationController pushViewController:altFirstViewController animated:YES];
}
							
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.navigationController.navigationBar.tintColor= [UIColor blackColor];
    
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

@end
