//
//  CustomCellView.h
//  Project1
//
//  Created by Mark Evans on 5/29/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCellView : UITableViewCell
{
    IBOutlet UILabel *textLabel;
    IBOutlet UILabel *statusLabel;
}

@property (nonatomic, retain) UILabel *statusLabel;

@end
