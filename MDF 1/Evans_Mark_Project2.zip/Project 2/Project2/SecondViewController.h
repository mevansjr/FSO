//
//  SecondViewController.h
//  Project2
//
//  Created by Mark Evans on 6/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SecondViewController : UIViewController <UITableViewDelegate>
{
    IBOutlet UITableView *tableView2;
    NSMutableArray *myPlayers;
    NSArray *status;
}

@property NSMutableArray *myPlayers;
@property NSArray *status;

@end
