//
//  AltFirstViewController.m
//  Project2
//
//  Created by Mark Evans on 6/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "AltFirstViewController.h"
#import "FirstViewDetails.h"
#import "CustomCellView2.h"

@interface AltFirstViewController ()

@end

@implementation AltFirstViewController
@synthesize newsUpdates;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    newsUpdates = [[NSMutableArray alloc] initWithObjects: @"Terrell Suggs is out for the year!", @"Ray Rice not reporting to camp.", @"Haloti Ngata is still recovering from last year's injury.", @"Raven's schedule is set!", nil];
 
    [super viewDidLoad];
    self.title = @"News & Updates";
    self.navigationController.navigationBar.tintColor=[UIColor blackColor];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return newsUpdates.count;  
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
//    static NSString *CellIdentifier = @"Cell";
//    
//    UITableViewCell *cell = [newsTableView dequeueReusableCellWithIdentifier:CellIdentifier];
//    if (cell == nil)
//    {
//        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
//    }
//    cell.textLabel.text = [newsUpdates objectAtIndex:indexPath.row];
//    
//    return cell;
    
    static NSString *CellIdentifier = @"Cell";
    
    CustomCellView2 *cell = [newsTableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"CustomCellView2" owner:nil options:nil];
        
        for (UIView *view in views)
        {
            if([view isKindOfClass:[CustomCellView2 class]])
            {
                //Cell Background Image
                cell.contentView.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"cellbg.png"]];
                cell = (CustomCellView2*)view;
                cell.textLabel.text = (NSString*)[newsUpdates objectAtIndex:indexPath.row];
                //cell.statusLabel.text = (NSString*)[status objectAtIndex:indexPath.row];
            }
        }
    }
    cell.contentView.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"cellbg.png"]];
    
    cell.textLabel.text = (NSString*)[newsUpdates objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //Code to click through to detailed view controller
//    NSString *showMsg = [newsUpdates objectAtIndex:indexPath.row];
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:showMsg delegate:nil cancelButtonTitle:@"Done" otherButtonTitles:nil, nil];
//    [alert show];
    
    FirstViewDetails *firstViewDetails = [[FirstViewDetails alloc] initWithNibName:@"FirstViewDetails" bundle:nil];
    if (firstViewDetails != nil)
    {
        //[self presentModalViewController:firstViewDetails animated:TRUE];
        [self.navigationController pushViewController:firstViewDetails animated:YES];
        //pushes players name from table to label on DetailsViewController
        [firstViewDetails changeNewsText:[newsUpdates objectAtIndex:indexPath.row]];
    }
    
}

@end
