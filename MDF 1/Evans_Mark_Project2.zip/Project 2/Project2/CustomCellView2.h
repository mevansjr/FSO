//
//  CustomCellView2.h
//  Project2
//
//  Created by Mark Evans on 6/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCellView2 : UITableViewCell
{
    IBOutlet UILabel *textLabel;
}


@end
