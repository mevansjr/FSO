//
//  SecondViewController.m
//  Project2
//
//  Created by Mark Evans on 6/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SecondViewController.h"
#import "CustomCellView.h"
#import "AltSecondViewController.h"

@implementation SecondViewController
@synthesize myPlayers;
@synthesize status;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        self.title = NSLocalizedString(@"Roster", @"Roster");
        self.tabBarItem.image = [UIImage imageNamed:@"Football"];
        
    }
    return self;
}

- (void)viewDidLoad
{
    self.navigationItem.title = @"Roster";
    self.navigationController.navigationBar.tintColor=[UIColor blackColor];
    UIBarButtonItem *rightButton =[[UIBarButtonItem alloc]initWithTitle:@"Edit" style:UIBarButtonItemStylePlain target:self action:@selector(toggleEdit)];
    self.navigationItem.rightBarButtonItem = rightButton;
    myPlayers = [[NSMutableArray alloc] initWithObjects: @"Ray Lewis", @"Ed Reed", @"Ray Rice", @"Joe Flacco", @"Anquan Boldin", @"Torrey Smith", @"Terrel Suggs", @"Ed Dickson", @"Dennis Pita", @"Vonta Leach", @"Matt Birk", @"Michael Oher", @"Billy Cundiff", @"Sam Koch", @"Sergiel Kindle", @"Paul Kurger", @"Daniel Elderbe", @"Haloti Ngata", @"Terrence Cody", @"Anthony Allen", nil];
    status = [[NSArray alloc] initWithObjects: @"Active", @"Active", @"Active", @"Active", @"Active", @"IR", @"Active",  @"Retired", @"IR", @"Active", @"Active", @"Active", @"Active", @"Active", @"Active", @"IR", @"Active",  @"Retired", @"IR", @"Active", nil];
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

-(void)toggleEdit{
    [tableView2 setEditing:!tableView2.editing animated:YES]; 
    
    if (tableView2.editing) 
    {
        [self.navigationItem.rightBarButtonItem setTitle:@"Done"];
    }
    else 
    {
        [self.navigationItem.rightBarButtonItem setTitle:@"Edit"];  
    }
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (void)viewDidAppear:(BOOL)animated
{
    //[tableView2 setEditing:true];
    [super viewDidAppear:animated];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return myPlayers.count;  
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(editingStyle == UITableViewCellEditingStyleDelete)
    {
        [myPlayers removeObjectAtIndex:indexPath.row];
        
        [tableView2 deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:true];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    CustomCellView *cell = [tableView2 dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"CustomCellView" owner:nil options:nil];
        
        for (UIView *view in views)
        {
            if([view isKindOfClass:[CustomCellView class]])
            {
                //Cell Background Image
                cell.contentView.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"cellbg.png"]];
                cell = (CustomCellView*)view;
                cell.textLabel.text = (NSString*)[myPlayers objectAtIndex:indexPath.row];
                cell.statusLabel.text = (NSString*)[status objectAtIndex:indexPath.row];
            }
        }
    }
    cell.contentView.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"cellbg.png"]];
    
    cell.textLabel.text = (NSString*)[myPlayers objectAtIndex:indexPath.row];
    cell.statusLabel.text = (NSString*)[status objectAtIndex:indexPath.row];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //Code to click through to detailed view controller
    NSLog(@"Table View Row Select");
    AltSecondViewController *altSecondViewController = [[AltSecondViewController alloc] initWithNibName:@"AltSecondViewController" bundle:nil];
    if (altSecondViewController != nil)
    {
        //[self presentModalViewController:altSecondViewController animated:TRUE];
        [self.navigationController pushViewController:altSecondViewController animated:YES];
        //pushes players name from table to label on DetailsViewController
        [altSecondViewController changeNameText:[myPlayers objectAtIndex:indexPath.row]];
    }
    
}

@end
