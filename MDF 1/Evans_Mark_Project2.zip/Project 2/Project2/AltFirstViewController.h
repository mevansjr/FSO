//
//  AltFirstViewController.h
//  Project2
//
//  Created by Mark Evans on 6/1/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AltFirstViewController : UIViewController <UITableViewDelegate>
{
    NSMutableArray *newsUpdates;
    IBOutlet UITableView *newsTableView;
}

@property (nonatomic, retain) NSMutableArray *newsUpdates;
@end
