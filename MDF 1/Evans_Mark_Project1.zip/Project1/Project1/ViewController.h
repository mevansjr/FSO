//
//  ViewController.h
//  Project1
//
//  Created by Mark Evans on 5/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController <UITableViewDelegate>
{
    IBOutlet UITableView *tableView2;
    NSMutableArray *myPlayers;
    NSArray *status;
}

-(IBAction)onClickEdit:(id)sender;
-(IBAction)onClickDone:(id)sender;

@property NSMutableArray *myPlayers;
@property NSArray *status;

@end
