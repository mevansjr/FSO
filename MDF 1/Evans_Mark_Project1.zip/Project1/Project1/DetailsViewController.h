//
//  DetailsViewController.h
//  Project1
//
//  Created by Mark Evans on 5/30/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailsViewController : UIViewController
{
    IBOutlet UILabel *playerName;
    IBOutlet UILabel *statusState;
}

-(IBAction)onClose:(id)sender;
-(IBAction)changeNameText:(NSString *)name;
-(IBAction)changeStatusText:(NSString *)status;

@end
