//
//  ViewController.m
//  Project1
//
//  Created by Mark Evans on 5/28/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//
// I used a Navigation Bar for my title instead of a UILabel. I also used BarButtonItems for my Edit/Done buttons.

#import "ViewController.h"
#import "CustomCellView.h"
#import "DetailsViewController.h"

@implementation ViewController
@synthesize myPlayers;
@synthesize status;

- (void)viewDidLoad
{
    self.navigationItem.title = @"Baltimore Ravens";
    myPlayers = [[NSMutableArray alloc] initWithObjects: @"Ray Lewis", @"Ed Reed", @"Ray Rice", @"Joe Flacco", @"Aquan Boldin", @"Torrey Smith", @"Terrel Suggs", @"Ed Dickson", @"Dennis Pita", @"Vonta Leach", @"Matt Birk", @"Michael Oher", @"Billy Cundiff", @"Sam Koch", @"Sergiel Kindle", @"Paul Kurger", @"Daniel Elderbe", @"Haloti Ngata", @"Terrence Cody", @"Anthony Allen", nil];
    status = [[NSArray alloc] initWithObjects: @"Active", @"Active", @"Active", @"Active", @"Active", @"Injured Reserve", @"Active",  @"Retired", @"Injured Reserve", @"Active", @"Active", @"Active", @"Active", @"Active", @"Active", @"Injured Reserve", @"Active",  @"Retired", @"Injured Reserve", @"Active", nil];
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (void)viewDidAppear:(BOOL)animated
{
    //[tableView2 setEditing:true];
    [super viewDidAppear:animated];
}
    

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return myPlayers.count;  
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(editingStyle == UITableViewCellEditingStyleDelete)
    {
        [myPlayers removeObjectAtIndex:indexPath.row];
        
        [tableView2 deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:true];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    CustomCellView *cell = [tableView2 dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"CustomCellView" owner:nil options:nil];
        
        for (UIView *view in views)
        {
            if([view isKindOfClass:[CustomCellView class]])
            {
                //Cell Background Image
                cell.contentView.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"cellbg.png"]];
                cell = (CustomCellView*)view;
                cell.textLabel.text = (NSString*)[myPlayers objectAtIndex:indexPath.row];
                cell.statusLabel.text = (NSString*)[status objectAtIndex:indexPath.row];
            }
        }
    }
    cell.contentView.backgroundColor = [[UIColor alloc] initWithPatternImage:[UIImage imageNamed:@"cellbg.png"]];

    cell.textLabel.text = (NSString*)[myPlayers objectAtIndex:indexPath.row];
    cell.statusLabel.text = (NSString*)[status objectAtIndex:0];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //Code to click through to detailed view controller
    DetailsViewController *viewController = [[DetailsViewController alloc] initWithNibName:@"DetailsViewController" bundle:nil];
    if (viewController != nil)
    {
        [self presentModalViewController:viewController animated:TRUE];
        //pushes players name from table to label on DetailsViewController
        [viewController changeNameText:[myPlayers objectAtIndex:indexPath.row]];
        //pushes status from table to label on DetailsViewController
        [viewController changeStatusText:[status objectAtIndex:indexPath.row]];
    }
}

-(IBAction)onClickEdit:(id)sender
{
    [tableView2 setEditing:true];
    NSLog(@"Edit button was pushed");
}

-(IBAction)onClickDone:(id)sender
{
    [tableView2 setEditing:false];
    NSLog(@"Done button was pushed");
}

@end
