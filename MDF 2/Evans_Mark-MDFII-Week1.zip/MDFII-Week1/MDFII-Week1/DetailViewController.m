//
//  DetailViewController.m
//  MDFII-Week1
//
//  Created by Mark Evans on 7/30/12.
//  Copyright (c) 2012 Mark Evans. All rights reserved.
//

#import "DetailViewController.h"
#import <EventKit/EventKit.h>
#import "ViewController.h"

@interface DetailViewController ()

@end

@implementation DetailViewController
@synthesize savedDate, savedTitle, savedLocation, calendars;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    theTableView.hidden = true;
    
    EKEventStore *eventStore = [[EKEventStore alloc] init];
    if (eventStore != nil)
    {
        // Stores calendars in an Array
        calendars = [eventStore calendars];
    
        NSDate *startDate = [NSDate date];
        // Stores calendars in an Array
        calendars = [eventStore calendars];
        NSDate *endDate = [[NSDate alloc]initWithTimeInterval:31536000 sinceDate:startDate];
        NSPredicate *predicate = [eventStore predicateForEventsWithStartDate:startDate endDate:endDate calendars:nil];
        NSArray *aEvents = [eventStore eventsMatchingPredicate:predicate];
        if (aEvents != nil)
        {
            NSLog(@"STARTING -------------- %@", [aEvents description]);
        }
    }
    
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)passTitle:(NSString *)passedTitle passDate:(NSString *)passedDate passLocation:(NSString *)loc
{
    self.title = passedTitle;
    theDate.text = passedDate;
    theTitle.text = passedTitle;
    theLocation.text = loc;
}

- (IBAction)addToCal:(id)sender
{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Alert" message:@"Do you want to add Event to your Calendar?" delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes", nil];
    [alert show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
	
	if([title isEqualToString:@"Yes"])
	{
        ViewController *viewController = [[ViewController alloc]initWithNibName:@"ViewController" bundle:nil];
        viewController.handler = ^(NSString* passString)
        {
            EKEventStore *eventStore = [[EKEventStore alloc] init];
            EKEvent *event = [EKEvent eventWithEventStore:eventStore];
            if (event != nil)
            {
                event.title = passString;
                event.startDate = [NSDate date];
                event.endDate = [[NSDate alloc] initWithTimeInterval:7200 sinceDate:event.startDate];
                //event.location = savedLocation;
                // Event saved to Default Calendar
                event.calendar = [eventStore defaultCalendarForNewEvents];
                NSError *error;
                [eventStore saveEvent:event span:EKSpanThisEvent error:&error];
            }
            NSLog(@"-alert window - %@", passString);
        };
            [self dismissModalViewControllerAnimated:true];
	}
}

-(IBAction)onClose:(id)sender
{
    [self dismissModalViewControllerAnimated:true];
}

- (IBAction)showCals:(id)sender
{
    theTableView.hidden = false;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return calendars.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }
    
        EKEventStore *eventStore = [[EKEventStore alloc] init];
        if (eventStore != nil)
        {
            calendars = [eventStore calendars];
            if (calendars != nil)
            {
                for (int i=0; i < [calendars count]; i++)
                {
                    EKCalendar *cal = [calendars objectAtIndex:i];
                    cell.textLabel.text = cal.title;
                }
            }
        }
    
        EKCalendar *cal = [calendars objectAtIndex:indexPath.row];
    	cell.textLabel.text = cal.title;
        
        return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //NSLog(@"You hit select!");
}

@end
