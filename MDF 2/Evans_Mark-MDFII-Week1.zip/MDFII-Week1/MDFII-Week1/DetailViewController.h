//
//  DetailViewController.h
//  MDFII-Week1
//
//  Created by Mark Evans on 7/30/12.
//  Copyright (c) 2012 Mark Evans. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <EventKit/EventKit.h>

@interface DetailViewController : UIViewController <UIAlertViewDelegate, UITableViewDataSource, UITableViewDelegate>
{
    NSString *savedTitle;
    NSString *savedDate;
    NSString *savedLocation;
    IBOutlet UILabel *theTitle;
    IBOutlet UILabel *theDate;
    IBOutlet UILabel *theLocation;
    IBOutlet UIButton *addToCalButton;
    IBOutlet UITableView *theTableView;
    NSArray *calendars;
}
@property (nonatomic, strong) NSString *savedTitle;
@property (nonatomic, strong) NSString *savedDate;
@property (nonatomic, strong) NSString *savedLocation;
@property (nonatomic, strong) NSArray *calendars;
- (void)passTitle:(NSString *)passedTitle passDate:(NSString *)passedDate passLocation:(NSString *)loc;
- (IBAction)addToCal:(id)sender;
- (IBAction)showCals:(id)sender;
-(IBAction)onClose:(id)sender;

@end
