//
//  ViewController.h
//  MDFII-Week1
//
//  Created by Mark Evans on 7/30/12.
//  Copyright (c) 2012 Mark Evans. All rights reserved.
//

#import <UIKit/UIKit.h>
typedef void (^CloseHandler)(NSString*);

@interface ViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
{
    IBOutlet UITableView *myTableView;
    NSMutableArray *events;
    NSMutableArray *dates;
    NSMutableArray *locations;
}

@property (nonatomic, strong) CloseHandler handler;
@property (nonatomic, strong) NSArray *calendars;
@property (nonatomic, copy) NSMutableArray *events;
@property (nonatomic, copy) NSMutableArray *dates;
@property (nonatomic, copy) NSMutableArray *locations;

@end
