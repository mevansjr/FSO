//
//  ViewController.m
//  MDFII-Week1
//
//  Created by Mark Evans on 7/30/12.
//  Copyright (c) 2012 Mark Evans. All rights reserved.
//

/*
Your project will need to have the following features:
>- Provide a table view list of ten or more fictional events.
>- Each table view cell must include an image, the event title and the event date.
>- When the user clicks on a tablecell event, present the user with a detailed event view.
>- The detailed event view will need to present the following information. The event title, location, time and date.
>- Include a button called "Add Event to Calendar". This will present the user with a calendar confirmation alert. If the user select yes, then add the event to the default user calendar.
>- Include a UI button that presents the user with a list of calendars on their device.
>- Take advantage of local notifications to notify the user 30 seconds after the application has closed to re-open it. Clicking on the message will re-open the app.
*/

#import "ViewController.h"
#import "CustomViewCell.h"
#import "DetailViewController.h"
#import <EventKit/EventKit.h>

@interface ViewController ()

@end

@implementation ViewController
@synthesize events, dates, calendars, handler;

- (void)viewDidLoad
{
   self.navigationController.navigationBar.tintColor = [UIColor colorWithRed:0.7627 green:0.0 blue:0.0 alpha:1.0];
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    NSDate *notifyDate = [[NSDate date] dateByAddingTimeInterval:30];
    UILocalNotification *theNotification = [[UILocalNotification alloc] init];
    if (theNotification != nil)
    {
        theNotification.fireDate = notifyDate;
        theNotification.timeZone = [NSTimeZone localTimeZone];
        theNotification.alertBody = @"We miss you, please come back!";
        theNotification.alertAction = @"Open";
        [[UIApplication sharedApplication] scheduleLocalNotification:theNotification];
    }
    self.title = @"Calendar Events";
    
    NSDate *date0 = [NSDate dateWithTimeIntervalSinceNow:86400+370];
    NSDate *date1 = [NSDate dateWithTimeIntervalSinceNow:86400*2+122];
    NSDate *date2 = [NSDate dateWithTimeIntervalSinceNow:86400*3+42];
    NSDate *date3 = [NSDate dateWithTimeIntervalSinceNow:86400*4+221];
    NSDate *date4 = [NSDate dateWithTimeIntervalSinceNow:86400*5+382];
    NSDate *date5 = [NSDate dateWithTimeIntervalSinceNow:86400*6+1122];
    NSDate *date6 = [NSDate dateWithTimeIntervalSinceNow:86400*7+334];
    NSDate *date7 = [NSDate dateWithTimeIntervalSinceNow:86400*8+765];
    NSDate *date8 = [NSDate dateWithTimeIntervalSinceNow:86400*9+1234];
    NSDate *date9 = [NSDate dateWithTimeIntervalSinceNow:86400*10+762];
    
    events = [[NSMutableArray alloc]initWithObjects:@"Go to Church", @"Soccer Practice", @"Meeting with Josh", @"Braden's Birthday", @"Vacation in the Bahamas!", @"Go to the Orioles Game!", @"Birthday for Ms. Ana!", @"Meeting with Rick", @"Meeting with Boss.", @"Vacation in New Jersey.", nil ];
    dates = [[NSMutableArray alloc]initWithObjects: date0, date1, date2, date3, date4, date5, date6, date7, date8, date9, nil];
    locations = [[NSMutableArray alloc]initWithObjects:@"Church", @"School Field", @"Josh's House", @"Home", @"Bahamas", @"Camden Yards, Baltimore MD", @"Mother-in-laws House", @"Rick's House", @"The Office", @"Wildwood, NJ", nil ];
    [super viewDidLoad];
    DetailViewController *detailView = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:nil];
    [detailView viewDidLoad];
    [myTableView reloadData];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return events.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    CustomViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil)
    {
        NSArray *views = [[NSBundle mainBundle] loadNibNamed:@"CustomViewCell" owner:nil options:nil];
        
        for (UIView *view in views)
        {
            if([view isKindOfClass:[CustomViewCell class]])
            {
                cell = (CustomViewCell*)view;
                cell.textLabel.text = [events objectAtIndex:indexPath.row];
                NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
                [dateFormat setDateFormat:@"yyyy-MM-dd 'at' HH:mm"];
                
                NSDate *tDate = [dates objectAtIndex:indexPath.row];
                NSString *fDate = [dateFormat stringFromDate:tDate];
                cell.statusLabel.text = fDate;
            }
        }
        cell.textLabel.text = [events objectAtIndex:indexPath.row];
        
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        [dateFormat setDateFormat:@"yyyy-MM-dd 'at' HH:mm"];
        
        NSDate *tDate = [dates objectAtIndex:indexPath.row];
        NSString *fDate = [dateFormat stringFromDate:tDate];
        cell.statusLabel.text = fDate;
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    DetailViewController *detailView = [[DetailViewController alloc] initWithNibName:@"DetailViewController" bundle:nil];
    NSString *theTitle = [events objectAtIndex:indexPath.row];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"yyyy-MM-dd 'at' HH:mm"];
    NSDate *tDate = [dates objectAtIndex:indexPath.row];
    NSString *fDate = [dateFormat stringFromDate:tDate];
    NSString *theLocation = [locations objectAtIndex:indexPath.row];
    if (handler != nil)
    {
        handler(theTitle);
    }
    [self presentModalViewController:detailView animated:true];
    [detailView passTitle:theTitle passDate:fDate passLocation:theLocation];
}

@end
