//
//  CustomViewCell.h
//  MDFII-Week1
//
//  Created by Mark Evans on 7/30/12.
//  Copyright (c) 2012 Mark Evans. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomViewCell : UITableViewCell
{
    IBOutlet UILabel *textLabel;
    IBOutlet UILabel *statusLabel;
}
@property (nonatomic, strong) UILabel *textLabel;
@property (nonatomic, strong) UILabel *statusLabel;
@end
