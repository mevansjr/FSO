//
//  Event.m
//  MDFII-Week1
//
//  Created by Mark Evans on 7/30/12.
//  Copyright (c) 2012 Mark Evans. All rights reserved.
//

#import "Event.h"

@implementation Event

-initWithTitle:(NSString *)title andDate:(NSString *)date
{
    eventTitle = title;
    eventDate = date;
}

@end
