//
//  Event.h
//  MDFII-Week1
//
//  Created by Mark Evans on 7/30/12.
//  Copyright (c) 2012 Mark Evans. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Event : NSObject
{
    NSString *eventTitle;
    NSString *eventDate;
}
-initWithTitle:(NSString *)title andDate:(NSString *)date;
@end
