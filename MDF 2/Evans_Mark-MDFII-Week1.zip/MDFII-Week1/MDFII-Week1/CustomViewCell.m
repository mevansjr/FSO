//
//  CustomViewCell.m
//  MDFII-Week1
//
//  Created by Mark Evans on 7/30/12.
//  Copyright (c) 2012 Mark Evans. All rights reserved.
//

#import "CustomViewCell.h"

@implementation CustomViewCell
@synthesize textLabel, statusLabel;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
