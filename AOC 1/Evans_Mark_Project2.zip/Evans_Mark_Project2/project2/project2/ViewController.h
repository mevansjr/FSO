//
//  ViewController.h
//  project2
//
//  Created by Mark Evans on 4/4/12.
//  Copyright (c) 2012 MdTA / Full Sail University. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UILabel *labelTitle;
    UILabel *labelAuthor;
    UILabel *labelAuthorText;    
    UILabel *labelPublished;    
    UILabel *labelPublishedDate;    
    UILabel *labelSummary;  
    UILabel *labelSummaryDetails;
    UILabel *labelItemList;
    UILabel *labelItemDetails;  
    
}
@end