//
//  project1Tests.m
//  project1Tests
//
//  Created by Mark Evans on 3/26/12.
//  Copyright (c) 2012 MdTA / Full Sail University. All rights reserved.
//

#import "project1Tests.h"

@implementation project1Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in project1Tests");
}

@end
