//
//  project1Tests.h
//  project1Tests
//
//  Created by Mark Evans on 3/26/12.
//  Copyright (c) 2012 MdTA / Full Sail University. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface project1Tests : SenTestCase

@end
