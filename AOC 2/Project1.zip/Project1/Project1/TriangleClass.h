//
//  TriangleClass.h
//
//  Created by Mark Evans on 5/3/12.
//  Copyright (c) 2012 MdTA / Full Sail University. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ShapeClass.h"

@interface TriangleClass : ShapeClass


@end
